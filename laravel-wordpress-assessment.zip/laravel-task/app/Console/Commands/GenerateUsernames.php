<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class GenerateUsernames extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:generate-usernames';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate usernames for existing users who do not have one';

    /**
     * Generate a username from a name.
     */
    protected function generateUsername($name, $existingUsernames)
    {
        // Convert to lowercase and replace spaces with dots
        $baseUsername = strtolower(str_replace(' ', '.', trim($name)));

        // Remove special characters except dots
        $baseUsername = preg_replace('/[^a-z0-9.]/', '', $baseUsername);

        // Initial try with just the name
        $username = $baseUsername;
        $counter = 1;

        // Keep trying with incremental numbers until we find an available username
        while (in_array($username, $existingUsernames)) {
            $username = $baseUsername . $counter;
            $counter++;
        }

        return $username;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Starting username generation for existing users...');

        // Get all users without usernames
        $users = \App\Models\User::whereNull('username')->get();
        $totalUsers = $users->count();

        if ($totalUsers === 0) {
            $this->info('No users found without usernames.');
            return;
        }

        // Get existing usernames to avoid duplicates
        $existingUsernames = \App\Models\User::whereNotNull('username')
            ->pluck('username')
            ->toArray();

        $bar = $this->output->createProgressBar($totalUsers);
        $bar->start();

        foreach ($users as $user) {
            $username = $this->generateUsername($user->name, $existingUsernames);
            $user->username = $username;
            $user->save();

            // Add the new username to our list of existing ones
            $existingUsernames[] = $username;

            $bar->advance();
        }

        $bar->finish();
        $this->newLine();
        $this->info("Successfully generated usernames for {$totalUsers} users.");
    }
}
