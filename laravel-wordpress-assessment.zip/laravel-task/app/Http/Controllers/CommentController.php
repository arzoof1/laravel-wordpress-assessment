<?php

namespace App\Http\Controllers;

// use Illuminate\Http\Request;

use App\Models\Comment;
use App\Models\Feedback;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    public function index($feedbackId)
    {
        $comments = Comment::with('user')
            ->where('feedback_id', $feedbackId)
            ->orderBy('created_at', 'asc')
            ->paginate(10);

        // Format comment content for bold, italic, code blocks, and mentions
        $comments->getCollection()->transform(function ($comment) {
            return [
                'id' => $comment->id,
                'user' => $comment->user ? $comment->user->name : null,
                'date' => $comment->created_at->toDateTimeString(),
                'content' => $this->formatComment($comment->content),
            ];
        });

        return response()->json($comments);
    }

    // Format comment content
    protected function formatComment($content)
    {
        // Escape HTML first to prevent XSS
        $content = htmlspecialchars($content, ENT_QUOTES, 'UTF-8');

        // Code block: ```code``` (process first to prevent formatting inside code blocks)
        $content = preg_replace_callback('/```([\s\S]*?)```/', function ($matches) {
            // Remove any HTML escaping inside code blocks
            return '<pre><code>' . trim($matches[1]) . '</code></pre>';
        }, $content);

        // Bold: **text** (not inside code blocks)
        $content = preg_replace('/\*\*((?!\<\/?pre\>).*?)\*\*/', '<strong>$1</strong>', $content);

        // Italic: *text* (not inside code blocks)
        $content = preg_replace('/(?<!\*)\*([^\*]+)\*(?!\*)/', '<em>$1</em>', $content);

        // User mention: @username (including dots and underscores)
        $content = preg_replace('/@([a-zA-Z0-9._]+)/', '<span class="mention">@$1</span>', $content);

        // Convert line breaks to <br>
        $content = nl2br($content);

        return $content;
    }

    public function store(Request $request, $feedbackId)
    {
        $request->validate([
            'content' => 'required|string',
        ]);

        $content = $request->input('content');
        $comment = Comment::create([
            'feedback_id' => $feedbackId,
            'user_id' => Auth::id(),
            'content' => $content,
        ]);

        // Bonus: Notify mentioned users (simple placeholder logic)
        preg_match_all('/@(\w+)/', $content, $matches);
        $mentionedUsernames = $matches[1] ?? [];
        // Here you could send notifications to mentioned users
        // Example: User::whereIn('name', $mentionedUsernames)->get();

        return response()->json($comment, 201);
    }
}
