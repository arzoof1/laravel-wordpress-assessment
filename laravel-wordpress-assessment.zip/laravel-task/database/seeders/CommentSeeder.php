<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Feedback;
use App\Models\Comment;

class CommentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all();
        $feedbacks = Feedback::all();

        foreach ($feedbacks as $feedback) {
            // Add 2-5 random comments to each feedback
            $commentCount = rand(2, 5);

            for ($i = 0; $i < $commentCount; $i++) {
                $user = $users->random();
                $mentionUser = $users->random();

                // Create comments with different formatting options
                $commentTemplates = [
                    "Great suggestion! Real-time notifications would be a game changer. @{$mentionUser->username}",
                    "*I noticed the typo too. Thanks for pointing it out!*",
                    "Here's a quick fix for the bug:\n```\nCheck the spelling in resources/views/dashboard.blade.php\n```",
                    "Supporting multiple languages will help us reach more users globally. /cc @{$mentionUser->username}",
                    "Optimizing image uploads is crucial for user experience. Let's prioritize this!",
                ];

                Comment::create([
                    'content' => $commentTemplates[array_rand($commentTemplates)],
                    'feedback_id' => $feedback->id,
                    'user_id' => $user->id,
                    'created_at' => now()->subHours(rand(1, 48)), // Random time within last 48 hours
                ]);
            }
        }
    }
}
