<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Feedback;

class FeedbackSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all();

        $feedbackData = [
            [
                'title' => 'Add Real-Time Notifications',
                'description' => 'Implement push notifications for instant updates on new comments and feedback.',
                'category' => 'feature request',
            ],
            [
                'title' => 'Typo in Dashboard Heading',
                'description' => 'The dashboard header has a spelling mistake. Please correct it to "Overview".',
                'category' => 'bug report',
            ],
            [
                'title' => 'Support for Multiple Languages',
                'description' => 'Allow users to switch between different languages in the app settings.',
                'category' => 'improvement',
            ],
            [
                'title' => 'Optimize Image Uploads',
                'description' => 'Image uploads are slow and sometimes fail. Consider using a CDN for better performance.',
                'category' => 'improvement',
            ],
        ];

        foreach ($feedbackData as $data) {
            // Randomly assign a user for each feedback
            $user = $users->random();

            Feedback::create([
                'title' => $data['title'],
                'description' => $data['description'],
                'category' => $data['category'],
                'user_id' => $user->id,
            ]);
        }
    }
}
