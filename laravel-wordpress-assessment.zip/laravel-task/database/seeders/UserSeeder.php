<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create main test user
        User::create([
            'name' => 'Emma Carter',
            'email' => 'emma.carter@example.com',
            'password' => Hash::make('securepass'),
            'username' => 'emma_carter',
        ]);

        // Create some sample users for testing mentions and interactions
        $users = [
            [
                'name' => 'Liam Nguyen',
                'email' => 'liam.nguyen@example.com',
                'username' => 'liam_nguyen',
            ],
            [
                'name' => 'Olivia Patel',
                'email' => 'olivia.patel@example.com',
                'username' => 'olivia_patel',
            ],
            [
                'name' => 'Noah Kim',
                'email' => 'noah.kim@example.com',
                'username' => 'noah_kim',
            ],
            [
                'name' => 'Sophia Garcia',
                'email' => 'sophia.garcia@example.com',
                'username' => 'sophia_garcia',
            ],
        ];

        foreach ($users as $userData) {
            User::create([
                'name' => $userData['name'],
                'email' => $userData['email'],
                'username' => $userData['username'],
                'password' => Hash::make('password123'), // Same password for all test users
            ]);
        }

        // Create some random users with the factory
        User::factory(5)->create();
    }
}
