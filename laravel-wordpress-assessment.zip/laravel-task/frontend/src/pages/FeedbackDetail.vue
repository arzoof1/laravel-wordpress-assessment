<template>
  <div class="feedback-detail">
    <h2>{{ feedback?.title }}</h2>
    <p><strong>Category:</strong> {{ feedback?.category }}</p>
    <p><strong>Submitted by:</strong> {{ feedback?.user?.name }}</p>
    <p>{{ feedback?.description }}</p>
    <h3>Comments</h3>
    <ul>
      <li v-for="comment in comments" :key="comment.id">
        <span v-html="comment.content"></span>
        <br />
        <small>{{ comment.user }} - {{ comment.date }}</small>
      </li>
    </ul>
    <form @submit.prevent="addComment">
      <div class="formatting-help">
        <p>Formatting options:</p>
        <ul>
          <li>**bold text**</li>
          <li>*italic text*</li>
          <li>```code block```</li>
          <li>@username to mention someone</li>
        </ul>
      </div>
      <div class="textarea-container">
        <textarea
          ref="textarea"
          v-model="newComment"
          placeholder="Add a comment..."
          required
          @input="handleInput"
          @keydown="handleKeydown"
        ></textarea>
        <div v-if="showMentions" class="mention-suggestions">
          <div
            v-for="user in mentionResults"
            :key="user.username"
            class="mention-item"
            @click="selectMention(user)"
          >
            <strong>{{ user.username }}</strong>
            <span>{{ user.name }}</span>
          </div>
        </div>
      </div>
      <button type="submit">Comment</button>
    </form>
  </div>
</template>
<script setup>
import { ref, onMounted, watch } from 'vue'
import api from '../api'
import { useRoute } from 'vue-router'
const feedback = ref(null)
const comments = ref([])
const newComment = ref('')
const route = useRoute()
const token = localStorage.getItem('token')

const mentionSearch = ref('')
const mentionResults = ref([])
const showMentions = ref(false)
const mentionStart = ref(-1)
const textarea = ref(null)
async function fetchFeedback() {
  try {
    const res = await api.get(`/api/feedback`, {
      headers: { Authorization: `Bearer ${token}` },
    })
    feedback.value = res.data.data.find((f) => f.id == route.params.id)
  } catch (err) {
    feedback.value = null
  }
}
async function fetchComments() {
  try {
    const res = await api.get(`/api/feedback/${route.params.id}/comments`, {
      headers: { Authorization: `Bearer ${token}` },
    })
    comments.value = res.data.data || res.data
  } catch (err) {
    comments.value = []
  }
}
async function addComment() {
  try {
    await api.post(
      `/api/feedback/${route.params.id}/comments`,
      {
        content: newComment.value,
      },
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    )
    newComment.value = ''
    fetchComments()
  } catch (err) {
    alert('Comment failed')
  }
}
async function handleInput(event) {
  const value = event.target.value
  const lastAtIndex = value.lastIndexOf('@')

  if (lastAtIndex !== -1) {
    const lastNewline = value.lastIndexOf('\n', lastAtIndex)
    const lastSpace = value.lastIndexOf(' ', lastAtIndex)
    const start = Math.max(lastNewline, lastSpace)

    if (lastAtIndex > start) {
      mentionStart.value = lastAtIndex
      // Changed to use a more permissive split pattern that keeps dots
      const query = value.slice(lastAtIndex + 1).match(/^[a-zA-Z0-9._]+/)?.[0] || ''

      if (query) {
        try {
          const res = await api.get('/api/users/search', {
            params: { query },
            headers: { Authorization: `Bearer ${token}` },
          })
          mentionResults.value = res.data
          showMentions.value = true
          return
        } catch (err) {
          console.error('Error searching users:', err)
        }
      }
    }
  }

  showMentions.value = false
}

function handleKeydown(event) {
  if (!showMentions.value) return

  if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
    event.preventDefault()
    // Handle selection in mention list
  } else if (event.key === 'Enter' && showMentions.value) {
    event.preventDefault()
    if (mentionResults.value.length > 0) {
      selectMention(mentionResults.value[0])
    }
  } else if (event.key === 'Escape') {
    showMentions.value = false
  }
}

function selectMention(user) {
  const before = newComment.value.slice(0, mentionStart.value)
  const after = newComment.value.slice(mentionStart.value).replace(/^@\w*/, '')
  newComment.value = before + '@' + user.username + after
  showMentions.value = false
  textarea.value?.focus()
}

onMounted(() => {
  fetchFeedback()
  fetchComments()
})
</script>
<style scoped>
.feedback-detail {
  max-width: 600px;
  margin: 2rem auto;
  padding: 2.5rem 2rem 2rem 2rem;
  background: linear-gradient(135deg, #f3e8ff 60%, #a7f3d0 100%);
  border-radius: 16px;
  box-shadow: 0 6px 24px rgba(124, 58, 237, 0.1);
  border: 1px solid #d1d5db;
  font-family: 'Inter', 'Nunito', Arial, sans-serif;
}
h2,
h3 {
  font-family: inherit;
  font-weight: 700;
  letter-spacing: 0.02em;
  color: #7c3aed;
}
textarea.nav-link {
  border: 1px solid #7c3aed;
  background: #f3e8ff;
  color: #0d9488;
}
button {
  background: linear-gradient(90deg, #7c3aed 60%, #0d9488 100%);
  color: #fff;
  font-weight: 700;
  letter-spacing: 0.01em;
  border: none;
  cursor: pointer;
  transition:
    background 0.2s,
    box-shadow 0.2s;
  padding: 0.95rem;
  border-radius: 7px;
  font-size: 1.08rem;
  margin-top: 0.5rem;
  box-shadow: 0 2px 8px rgba(124, 58, 237, 0.08);
}
button:disabled {
  background: #c4b5fd;
  cursor: not-allowed;
}
button:hover:not(:disabled) {
  background: linear-gradient(90deg, #0d9488 60%, #7c3aed 100%);
  box-shadow: 0 4px 16px rgba(13, 148, 136, 0.12);
}
.nav-link {
  color: #7c3aed;
  text-decoration: none;
  font-weight: 700;
  letter-spacing: 0.01em;
  padding: 0.3rem 0.8rem;
  border-radius: 6px;
  transition:
    background 0.2s,
    color 0.2s;
  font-size: 0.98rem;
}
.nav-link:hover {
  background: #a7f3d0;
  color: #0d9488;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  margin-bottom: 1.2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #eee;
}
form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
textarea,
button {
  padding: 0.75rem;
  border-radius: 4px;
  border: 1px solid #ccc;
  font-size: 1rem;
}
.textarea-container textarea {
  width: 100%;
  box-sizing: border-box;
}

/* Comment formatting styles */
:deep(pre) {
  background: #f8f8f8;
  padding: 1rem;
  border-radius: 4px;
  overflow-x: auto;
  margin: 0.5rem 0;
}

:deep(code) {
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 0.9em;
}

:deep(.mention) {
  color: #2196f3;
  font-weight: 500;
  cursor: pointer;
}

:deep(.mention:hover) {
  text-decoration: underline;
}

.textarea-container {
  position: relative;
  width: 100%;
}

.mention-suggestions {
  position: absolute;
  bottom: 100%;
  left: 0;
  width: 100%;
  max-height: 200px;
  overflow-y: auto;
  background: white;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
  z-index: 1000;
}

.mention-item {
  padding: 8px 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
}

.mention-item:hover {
  background: #f5f5f5;
}

.mention-item strong {
  color: #2196f3;
}

.mention-item span {
  color: #666;
  font-size: 0.9em;
}
</style>
