<template>
  <div class="feedback-list">
    <h2>Product Feedback</h2>
    <router-link to="/feedback/new" class="nav-link">Submit Feedback</router-link>
    <ul>
      <li v-for="item in feedback" :key="item.id">
        <strong>{{ item.title }}</strong> <span>({{ item.category }})</span> -
        <em>{{ item.user?.name }}</em>
        <router-link :to="`/feedback/${item.id}`" class="nav-link">View</router-link>
      </li>
    </ul>
    <!-- TODO: Pagination -->
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
const feedback = ref([])
onMounted(async () => {
  try {
    const token = localStorage.getItem('token')
    const res = await api.get('/api/feedback', {
      headers: { Authorization: `Bearer ${token}` },
    })
    feedback.value = res.data.data
  } catch (err) {
    feedback.value = []
  }
})
</script>
<style scoped>
/* Card style for feedback list */
.feedback-list {
  max-width: 600px;
  margin: 2rem auto;
  padding: 2.5rem 2rem 2rem 2rem;
  background: linear-gradient(135deg, #f3e8ff 60%, #a7f3d0 100%);
  border-radius: 16px;
  box-shadow: 0 6px 24px rgba(124, 58, 237, 0.1);
  border: 1px solid #d1d5db;
  font-family: 'Inter', 'Nunito', Arial, sans-serif;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  margin-bottom: 1.2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #eee;
}
h2 {
  font-family: inherit;
  font-weight: 700;
  letter-spacing: 0.02em;
  color: #7c3aed;
}
/* Nav link style */
.nav-link {
  color: #7c3aed;
  text-decoration: none;
  font-weight: 700;
  letter-spacing: 0.01em;
  padding: 0.3rem 0.8rem;
  border-radius: 6px;
  transition:
    background 0.2s,
    color 0.2s;
  font-size: 0.98rem;
}
.nav-link:hover {
  background: #a7f3d0;
  color: #0d9488;
}
</style>
