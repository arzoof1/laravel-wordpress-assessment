import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/login', component: () => import('../pages/Login.vue') },
    { path: '/register', component: () => import('../pages/Register.vue') },
    { path: '/', component: () => import('../pages/FeedbackList.vue') },
    { path: '/feedback/new', component: () => import('../pages/FeedbackForm.vue') },
    { path: '/feedback/:id', component: () => import('../pages/FeedbackDetail.vue'), props: true },
  ],
})

// Navigation guard for auth
router.beforeEach((to, from, next) => {
  const publicPages = ['/login', '/register']
  const authRequired = !publicPages.includes(to.path)
  const loggedIn = !!localStorage.getItem('token')
  if (authRequired && !loggedIn) {
    return next('/login')
  }
  next()
})

export default router
