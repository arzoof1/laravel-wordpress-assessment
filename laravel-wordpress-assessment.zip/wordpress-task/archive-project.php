<?php
/**
 * Archive template for Projects
 */
get_header();
?>

<main>
    <h2><?php _e('Projects Archive', 'customportfolio'); ?></h2>
    
    <!-- Filter form for projects -->
    <form method="get" class="project-filter">
        <label for="project_title"><?php _e('Project Title:', 'customportfolio'); ?></label>
        <input type="text" name="project_title" id="project_title" value="<?php echo esc_attr(isset($_GET['project_title']) ? $_GET['project_title'] : ''); ?>" placeholder="<?php _e('Search by title', 'customportfolio'); ?>">
        
        <label for="start_date"><?php _e('Start Date:', 'customportfolio'); ?></label>
        <input type="date" name="start_date" id="start_date" value="<?php echo esc_attr(isset($_GET['start_date']) ? $_GET['start_date'] : ''); ?>">
        
        <label for="end_date"><?php _e('End Date:', 'customportfolio'); ?></label>
        <input type="date" name="end_date" id="end_date" value="<?php echo esc_attr(isset($_GET['end_date']) ? $_GET['end_date'] : ''); ?>">
        
        <button type="submit"><?php _e('Filter', 'customportfolio'); ?></button>
    </form>

    <?php
    $args = array(
        'post_type' => 'project',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    );

    // Add title search
    if (!empty($_GET['project_title'])) {
        $args['s'] = sanitize_text_field($_GET['project_title']);
    }

    // Add date filters
    if (!empty($_GET['start_date']) || !empty($_GET['end_date'])) {
        $meta_query = array('relation' => 'AND');
        
        if (!empty($_GET['start_date'])) {
            $start_date = sanitize_text_field($_GET['start_date']);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
                $meta_query[] = array(
                    'key' => '_start_date',
                    'value' => $start_date,
                    'compare' => '>=',
                    'type' => 'DATE',
                );
            }
        }
        
        if (!empty($_GET['end_date'])) {
            $end_date = sanitize_text_field($_GET['end_date']);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
                $meta_query[] = array(
                    'key' => '_end_date',
                    'value' => $end_date,
                    'compare' => '<=',
                    'type' => 'DATE',
                );
            }
        }
        
        if (!empty($meta_query['relation'])) {
            $args['meta_query'] = $meta_query;
        }
    }

    $projects = new WP_Query($args);
    if ($projects->have_posts()) : ?>
        <div class="project-grid">
            <?php while ($projects->have_posts()) : $projects->the_post(); ?>
                <div class="project-card">
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo wp_trim_words(get_the_content(), 20); ?></p>
                </div>
            <?php endwhile; ?>
        </div>
        <?php wp_reset_postdata(); ?>
    <?php else : ?>
        <p><?php _e('No projects found.', 'customportfolio'); ?></p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>