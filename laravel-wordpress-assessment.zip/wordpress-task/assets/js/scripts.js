jQuery(document).ready(function($) {
    // Mobile menu toggle
    $('.mobile-menu-toggle').on('click', function() {
        $('.primary-menu').slideToggle(300).toggleClass('active');
        $(this).text($('.primary-menu').hasClass('active') ? '✕' : '☰');
    });

    // Sub-menu toggle for mobile
    $('.menu-item-has-children > a').on('click', function(e) {
        if ($(window).width() < 768) {
            e.preventDefault();
            $(this).next('.sub-menu').slideToggle(300);
            $(this).parent().toggleClass('open');
        }
    });

    // Close menu when clicking outside
    $(document).on('click', function(e) {
        if ($(window).width() < 768 && !$(e.target).closest('nav, .mobile-menu-toggle').length) {
            $('.primary-menu').slideUp(300).removeClass('active');
            $('.mobile-menu-toggle').text('☰');
        }
    });
});