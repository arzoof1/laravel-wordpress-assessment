<?php
/**
 * CustomPortfolio Theme Functions
 */

/* Theme setup */
function customportfolio_setup() {
    add_theme_support('title-tag');
    add_theme_support('menus');
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'customportfolio'),
    ));
}
add_action('after_setup_theme', 'customportfolio_setup');

/* Enqueue styles and scripts */
function customportfolio_enqueue_scripts() {
    wp_enqueue_style('customportfolio-main-style', get_template_directory_uri() . '/assets/css/styles.css', array(), '1.0.0');
    wp_enqueue_style('customportfolio-style', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_script('customportfolio-script', get_template_directory_uri() . '/assets/js/scripts.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'customportfolio_enqueue_scripts');

/* Register Projects custom post type */
function customportfolio_register_project_cpt() {
    $labels = array(
        'name' => __('Projects', 'customportfolio'),
        'singular_name' => __('Project', 'customportfolio'),
        'menu_name' => __('Projects', 'customportfolio'),
        'add_new' => __('Add New Project', 'customportfolio'),
        'add_new_item' => __('Add New Project', 'customportfolio'),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-portfolio',
    );

    register_post_type('project', $args);
}
add_action('init', 'customportfolio_register_project_cpt');

/* Add meta box for Project fields */
function customportfolio_add_project_meta_box() {
    add_meta_box(
        'project_fields',
        __('Project Details', 'customportfolio'),
        'customportfolio_render_project_meta_box',
        'project',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'customportfolio_add_project_meta_box');

/* Render meta box fields */
function customportfolio_render_project_meta_box($post) {
    $project_start_date = get_post_meta($post->ID, '_start_date', true);
    $project_end_date = get_post_meta($post->ID, '_end_date', true);
    $project_url = get_post_meta($post->ID, '_project_url', true);

    wp_nonce_field('customportfolio_save_project_fields', 'customportfolio_project_nonce');
    ?>
    <p>
        <label for="project_start_date"><?php _e('Project Start Date', 'customportfolio'); ?></label><br>
        <input type="date" id="project_start_date" name="project_start_date" value="<?php echo esc_attr($project_start_date); ?>">
    </p>
    <p>
        <label for="project_end_date"><?php _e('Project End Date', 'customportfolio'); ?></label><br>
        <input type="date" id="project_end_date" name="project_end_date" value="<?php echo esc_attr($project_end_date); ?>">
    </p>
    <p>
        <label for="project_url"><?php _e('Project URL', 'customportfolio'); ?></label><br>
        <input type="url" id="project_url" name="project_url" value="<?php echo esc_attr($project_url); ?>" style="width: 100%;">
    </p>
    <?php
}

/* Save meta box data */
function customportfolio_save_project_fields($post_id) {
    if (!isset($_POST['customportfolio_project_nonce']) || !wp_verify_nonce($_POST['customportfolio_project_nonce'], 'customportfolio_save_project_fields')) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['project_start_date'])) {
        $start_date = sanitize_text_field($_POST['project_start_date']);
        if ($start_date && preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
            update_post_meta($post_id, '_start_date', $start_date);
        } else {
            delete_post_meta($post_id, '_start_date');
        }
    }
    if (isset($_POST['project_end_date'])) {
        $end_date = sanitize_text_field($_POST['project_end_date']);
        if ($end_date && preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
            update_post_meta($post_id, '_end_date', $end_date);
        } else {
            delete_post_meta($post_id, '_end_date');
        }
    }
    if (isset($_POST['project_url'])) {
        $url = esc_url_raw($_POST['project_url']);
        if ($url) {
            update_post_meta($post_id, '_project_url', $url);
        } else {
            delete_post_meta($post_id, '_project_url');
        }
    }
}
add_action('save_post', 'customportfolio_save_project_fields');

/* Register custom REST API endpoint for Projects */
function customportfolio_register_project_api() {
    register_rest_route('customportfolio/v1', '/projects', array(
        'methods' => 'GET',
        'callback' => 'customportfolio_get_projects',
        'permission_callback' => '__return_true',
    ));
}
add_action('rest_api_init', 'customportfolio_register_project_api');

function customportfolio_get_projects($request) {
    $args = array(
        'post_type' => 'project',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    );

    $projects = get_posts($args);
    $data = array();

    foreach ($projects as $project) {
        $data[] = array(
            'title' => esc_html(get_the_title($project->ID)),
            'url' => esc_url(get_post_meta($project->ID, '_project_url', true)),
            'start_date' => esc_html(get_post_meta($project->ID, '_start_date', true)),
            'end_date' => esc_html(get_post_meta($project->ID, '_end_date', true)),
        );
    }

    return rest_ensure_response($data);
}

/* Custom Walker for navigation menu */
class CustomPortfolio_Walker_Nav_Menu extends Walker_Nav_Menu {
    function start_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"sub-menu\">\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';

        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;

        // Check for children
        $args = is_object($args) ? $args : new stdClass();
        $has_children = in_array('menu-item-has-children', $classes);
        if ($has_children) {
            $classes[] = 'menu-item-has-children';
        }

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $output .= $indent . '<li' . $class_names . '>';

        $attributes = '';
        $attributes .= !empty($item->attr_title) ? ' title="' . esc_attr($item->attr_title) . '"' : '';
        $attributes .= !empty($item->target) ? ' target="' . esc_attr($item->target) . '"' : '';
        $attributes .= !empty($item->xfn) ? ' rel="' . esc_attr($item->xfn) . '"' : '';
        $attributes .= !empty($item->url) ? ' href="' . esc_attr($item->url) . '"' : '';

        $item_output = !empty($args->before) ? $args->before : '';
        $item_output .= '<a' . $attributes . '>';
        $item_output .= (!empty($args->link_before) ? $args->link_before : '') . apply_filters('the_title', $item->title, $item->ID) . (!empty($args->link_after) ? $args->link_after : '');
        $item_output .= '</a>';
        $item_output .= !empty($args->after) ? $args->after : '';

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

    function end_el(&$output, $item, $depth = 0, $args = null) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        $output .= "$indent</li>\n";
    }

    function end_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }
}
?>