<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme and one of the
 * two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 *
 * @package CustomPortfolio
 */

get_header();
?>

<main>
    <?php if (have_posts()) : ?>
        <h2><?php
            if (is_home()) {
                echo __('Latest Posts', 'customportfolio');
            } elseif (is_archive()) {
                the_archive_title();
            } elseif (is_search()) {
                printf(__('Search Results for: %s', 'customportfolio'), get_search_query());
            } else {
                echo __('Content', 'customportfolio');
            }
        ?></h2>

        <div class="content-grid">
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="entry-content">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <?php the_posts_navigation(); ?>
    <?php else : ?>
        <p><?php _e('No content found.', 'customportfolio'); ?></p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>