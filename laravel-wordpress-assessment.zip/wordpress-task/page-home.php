<?php
/*
Template Name: Home
*/
get_header();
?>

<main>
    <h2>Homepage</h2>
    <?php
    $args = array(
        'post_type' => ['post', 'project'],
        'posts_per_page' => 10,
    );
    $blog_posts = new WP_Query($args);
    if ($blog_posts->have_posts()) : ?>
        <div class="post-grid">
            <?php while ($blog_posts->have_posts()) : $blog_posts->the_post(); ?>
                <article>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="post-excerpt"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; ?>
        </div>
        <?php wp_reset_postdata(); ?>
    <?php else : ?>
        <p>No posts found.</p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>