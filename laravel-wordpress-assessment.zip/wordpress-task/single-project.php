<?php
/**
 * Template for displaying single Project
 */
get_header();
?>

<main>
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article class="project-details">
            <h2><?php the_title(); ?></h2>
            <div class="project-content"><?php the_content(); ?></div>
            
            <div class="project-meta">
                <p><strong>Start Date:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_start_date', true)); ?></p>
                <p><strong>End Date:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_end_date', true)); ?></p>
                <p><strong>Project URL:</strong> <a href="<?php echo esc_url(get_post_meta(get_the_ID(), '_project_url', true)); ?>" target="_blank"><?php echo esc_url(get_post_meta(get_the_ID(), '_project_url', true)); ?></a></p>
            </div>
        </article>
    <?php endwhile; else : ?>
        <p><?php _e('No project found.', 'customportfolio'); ?></p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>