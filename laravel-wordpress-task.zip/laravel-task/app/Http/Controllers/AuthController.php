<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    protected function generateUsername($name)
    {
        // Convert to lowercase and replace spaces and dots with underscores
        $baseUsername = strtolower(trim($name));
        $baseUsername = str_replace([' ', '.'], '_', $baseUsername);

        // Remove any special characters except underscores
        $baseUsername = preg_replace('/[^a-z0-9_]/', '', $baseUsername);

        // Remove consecutive underscores
        $baseUsername = preg_replace('/_+/', '_', $baseUsername);

        // Remove leading/trailing underscores
        $baseUsername = trim($baseUsername, '_');

        // Initial try with just the name
        $username = $baseUsername;
        $counter = 1;

        // Keep trying with incremental numbers until we find an available username
        while (User::where('username', $username)->exists()) {
            $username = $baseUsername . '_' . $counter;
            $counter++;
        }

        return $username;
    }

    public function register(Request $request)
    {
        try {
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users',
                'password' => 'required|string|min:8',
            ]);

            $username = $this->generateUsername($validated['name']);

            $user = User::create([
                'name' => $validated['name'],
                'username' => $username,
                'email' => $validated['email'],
                'password' => Hash::make($validated['password']),
            ]);

            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'access_token' => $token,
                'token_type' => 'Bearer',
                'user' => [
                    'name' => $user->name,
                    'username' => $user->username,
                    'email' => $user->email
                ]
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        // Generate username if it doesn't exist
        if (!$user->username) {
            $user->username = $this->generateUsername($user->name);
            $user->save();
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'access_token' => $token,
            'token_type' => 'Bearer',
            'user' => [
                'name' => $user->name,
                'username' => $user->username,
                'email' => $user->email
            ]
        ]);
    }

    public function searchUsers(Request $request)
    {
        $query = $request->get('query', '');

        $users = User::where('username', 'like', $query . '%')
            ->orWhere('name', 'like', '%' . $query . '%')
            ->select('name', 'username')
            ->limit(5)
            ->get();

        return response()->json($users);
    }

    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();
        return response()->json(['message' => 'Logged out']);
    }
}
