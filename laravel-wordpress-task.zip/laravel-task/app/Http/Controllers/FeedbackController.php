<?php

namespace App\Http\Controllers;

// use Illuminate\Http\Request;

use App\Models\Feedback;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FeedbackController extends Controller
{
    public function index()
    {
        $feedback = Feedback::with('user:id,name')->orderBy('created_at', 'desc')->paginate(10);
        // Only return title, category, and user info
        $feedback->getCollection()->transform(function ($item) {
            return [
                'id' => $item->id,
                'title' => $item->title,
                'category' => $item->category,
                'user' => $item->user ? ['id' => $item->user->id, 'name' => $item->user->name] : null,
            ];
        });
        return response()->json($feedback);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'category' => 'required|string|max:100',
        ]);

        $feedback = Feedback::create([
            'title' => $request->title,
            'description' => $request->description,
            'category' => $request->category,
            'user_id' => Auth::id(),
        ]);

        return response()->json($feedback, 201);
    }
}
