<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create users first as they are required for feedback and comments
        $this->call([
            UserSeeder::class,
            FeedbackSeeder::class,
            CommentSeeder::class,
        ]);
    }
}
