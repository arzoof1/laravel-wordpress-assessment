<script setup lang="ts">
import { ref } from 'vue'
import api from './api'
import { useRouter } from 'vue-router'
const loading = ref(false)
const error = ref('')
const router = useRouter()
import { onMounted } from 'vue'
const isLoggedIn = ref(!!localStorage.getItem('token'))
function updateLoginState() {
  isLoggedIn.value = !!localStorage.getItem('token')
}
onMounted(() => {
  window.addEventListener('storage', updateLoginState)
})
function loginStateChanged() {
  updateLoginState()
}
async function logout() {
  loading.value = true
  error.value = ''
  try {
    const token = localStorage.getItem('token')
    await api.post(
      '/api/logout',
      {},
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    )
  } catch (err) {
    error.value = 'Logout failed.'
  } finally {
    localStorage.removeItem('token')
    loginStateChanged()
    loading.value = false
    router.push('/login')
  }
}
</script>

<template>
  <nav class="navbar">
    <router-link to="/" class="nav-link" v-if="isLoggedIn">Feedback</router-link>
    <router-link to="/feedback/new" class="nav-link" v-if="isLoggedIn">Submit</router-link>
    <router-link to="/login" class="nav-link" v-if="!isLoggedIn">Login</router-link>
    <router-link to="/register" class="nav-link" v-if="!isLoggedIn">Register</router-link>
    <button v-if="isLoggedIn" @click="logout" class="nav-link logout-btn">Logout</button>
  </nav>
  <main>
    <div v-if="loading" class="spinner"></div>
    <div v-if="error" class="alert">{{ error }}</div>
    <router-view />
  </main>
</template>
<style scoped>
.app-root {
  font-family: 'Inter', 'Nunito', Arial, sans-serif;
  font-smooth: always;
  background: #f8fafc;
  min-height: 100vh;
  color: #2d3748;
}
.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #3498db;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
  margin: 2rem auto;
}
@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
.alert {
  background: #e74c3c;
  color: #fff;
  padding: 1rem;
  margin: 1rem auto;
  max-width: 400px;
  border-radius: 4px;
  text-align: center;
}
body,
.app-root {
  font-family: 'Inter', 'Nunito', Arial, sans-serif;
  font-smooth: always;
  background: #f8fafc;
  min-height: 100vh;
  color: #2d3748;
}
/* Navbar styling */
.navbar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  background: linear-gradient(90deg, #f3e8ff 60%, #a7f3d0 100%);
  border-radius: 16px;
  box-shadow: 0 4px 16px rgba(124, 58, 237, 0.08);
  padding: 1.2rem 2rem;
  margin: 2rem auto 2.5rem auto;
  max-width: 700px;
  font-family: 'Inter', 'Nunito', Arial, sans-serif;
}
.nav-link {
  display: inline-block;
  margin-right: 1rem;
  font-size: 1.08rem;
  background: none;
  color: #7c3aed;
  padding: 0.35rem 1rem;
  border-radius: 8px;
  font-weight: 600;
  text-decoration: none;
  letter-spacing: 0.01em;
  transition:
    background 0.2s,
    color 0.2s,
    box-shadow 0.2s;
  border: none;
  cursor: pointer;
  font-family: inherit;
}
.nav-link:hover {
  color: #0d9488;
  background: #a7f3d0;
  box-shadow: 0 2px 8px rgba(13, 148, 136, 0.08);
}
.nav-link.router-link-active {
  background: linear-gradient(90deg, #7c3aed 60%, #0d9488 100%);
  color: #fff;
  box-shadow: 0 2px 8px rgba(124, 58, 237, 0.08);
}
.logout-btn {
  background: linear-gradient(90deg, #7c3aed 60%, #0d9488 100%);
  color: #fff !important;
  font-weight: 700;
  border: none;
  padding: 0.35rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition:
    background 0.2s,
    color 0.2s,
    box-shadow 0.2s;
  box-shadow: 0 2px 8px rgba(124, 58, 237, 0.08);
  font-family: inherit;
}
.logout-btn:hover {
  background: linear-gradient(90deg, #0d9488 60%, #7c3aed 100%);
  color: #fff;
  box-shadow: 0 4px 16px rgba(13, 148, 136, 0.12);
}
main {
  min-height: 80vh;
  padding: 2rem 0;
  font-family: inherit;
}
@media (max-width: 600px) {
  .navbar {
    flex-direction: column;
    align-items: center;
  }
  main {
    padding: 1rem 0;
  }
}
</style>
