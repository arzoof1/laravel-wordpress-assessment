<template>
  <div class="register-page">
    <h2>Register</h2>
    <form @submit.prevent="register" style="margin-bottom: 1.5rem">
      <input v-model="name" type="text" placeholder="Name" required />
      <input v-model="email" type="email" placeholder="Email" required />
      <input v-model="password" type="password" placeholder="Password" required />
      <button type="submit" :disabled="loading">Register</button>
      <div v-if="error" class="form-error">{{ error }}</div>
      <div v-if="loading" class="spinner"></div>
    </form>
    <router-link to="/login" class="nav-link link-inline">Login</router-link>
  </div>
</template>
<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
const name = ref('')
const email = ref('')
const password = ref('')
const error = ref('')
const loading = ref(false)
const router = useRouter()
async function register() {
  error.value = ''
  loading.value = true
  try {
    await api.get('/sanctum/csrf-cookie')
    const res = await api.post('/api/register', {
      name: name.value,
      email: email.value,
      password: password.value,
    })
    localStorage.setItem('token', res.data.access_token)
    router.push('/')
  } catch (err) {
    if (err.response && err.response.data) {
      if (err.response.data.errors) {
        error.value = Object.values(err.response.data.errors).flat().join(' ')
      } else if (err.response.data.error) {
        error.value = err.response.data.error
      } else {
        error.value = JSON.stringify(err.response.data)
      }
    } else {
      error.value = 'Registration failed. Please check your details.'
    }
  } finally {
    loading.value = false
  }
}
</script>
<style scoped>
/* Card style for register */
.register-page {
  max-width: 400px;
  margin: 2rem auto;
  padding: 2.5rem 2rem 2rem 2rem;
  background: linear-gradient(135deg, #f3e8ff 60%, #a7f3d0 100%);
  border-radius: 16px;
  box-shadow: 0 6px 24px rgba(124, 58, 237, 0.1);
  border: 1px solid #d1d5db;
  font-family: 'Inter', 'Nunito', Arial, sans-serif;
}
h2 {
  font-family: inherit;
  font-weight: 700;
  letter-spacing: 0.02em;
  color: #7c3aed;
}
form {
  display: flex;
  flex-direction: column;
  gap: 1.1rem;
}
input,
button {
  padding: 0.8rem;
  border-radius: 7px;
  border: 1px solid #c4b5fd;
  font-size: 1rem;
  background: #f3e8ff;
  margin-bottom: 0.5rem;
  transition: border 0.2s;
  font-family: inherit;
  font-size: 1.05rem;
}
input:focus,
button:focus {
  border: 1.5px solid #7c3aed;
  outline: none;
}
button {
  background: linear-gradient(90deg, #7c3aed 60%, #0d9488 100%);
  color: #fff;
  font-weight: 700;
  letter-spacing: 0.01em;
  border: none;
  cursor: pointer;
  transition:
    background 0.2s,
    box-shadow 0.2s;
  padding: 0.95rem;
  border-radius: 7px;
  font-size: 1.08rem;
  margin-top: 0.5rem;
  box-shadow: 0 2px 8px rgba(124, 58, 237, 0.08);
}
button:disabled {
  background: #c4b5fd;
  cursor: not-allowed;
}
button:hover:not(:disabled) {
  background: linear-gradient(90deg, #0d9488 60%, #7c3aed 100%);
  box-shadow: 0 4px 16px rgba(13, 148, 136, 0.12);
}
.form-error {
  color: #7c3aed;
  background: #f3e8ff;
  padding: 0.7rem;
  border-radius: 8px;
  text-align: center;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(124, 58, 237, 0.08);
  font-family: inherit;
  font-weight: 600;
}
.link-inline {
  display: inline-block;
  margin-top: 1rem;
  font-size: 1rem;
  background: none;
  color: #7c3aed;
  padding: 0.2rem 0.6rem;
  border-radius: 4px;
  font-weight: 600;
  text-decoration: underline;
  transition: color 0.2s;
}
.link-inline:hover {
  color: #0d9488;
  background: #a7f3d0;
}
.spinner {
  border: 4px solid #f3e8ff;
  border-top: 4px solid #7c3aed;
  border-radius: 50%;
  width: 30px;
  height: 30px;
  animation: spin 1s linear infinite;
  margin: 1rem auto;
}
@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
</style>
