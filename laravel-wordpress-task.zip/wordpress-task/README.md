CustomPortfolio WordPress Theme

A custom WordPress theme designed to showcase projects with an elegant, responsive interface. Built as a test task for a full-stack developer role, it features a dynamic navigation menu, advanced project search, and custom fields for project management.

Features





Elegant Design: Sticky header with a blue gradient (#1a2a44 to #2e5cb8), clean typography (Roboto), and a responsive project grid.



Dynamic Navigation: Multi-level dropdown menus with hover effects, mobile-friendly hamburger toggle (hidden on desktop, styled on mobile).



Project Management:





Custom post type project with title (Project Name), content (Project Description), and meta fields (Start Date, End Date, URL).



Archive page (/project/) with title search and date filters.



Single project view with detailed metadata.



REST API: Endpoint (/wp-json/customportfolio/v1/projects) for retrieving project data.



Security: Input sanitization, output escaping, nonce verification, and permission checks.

